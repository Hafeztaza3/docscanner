package com.fegt.docscanner

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val dir by lazy { File(filesDir, "scans").apply { mkdirs() } }
    private var files: List<File> = emptyList()
    private val adapter by lazy { DocAdapter() }
    private lateinit var emptyView: View
    private lateinit var countView: TextView

    private val launcher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { r ->
        if (r.resultCode == RESULT_OK) {
            val uri = GmsDocumentScanningResult.fromActivityResultIntent(r.data)?.pdf?.uri
                ?: return@registerForActivityResult
            val name = "SAFHA_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".pdf"
            val out = File(dir, name)
            contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { i.copyTo(it) } }
            refresh()
            openPdf(out)
        }
    }

    override fun attachBaseContext(base: Context) {
        val saved = base.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LANG, null)
        val lang = saved ?: if (Locale.getDefault().language == "ar") "ar" else "fr"
        val locale = if (lang == "ar") Locale("ar", "MA") else Locale("fr", "FR")
        Locale.setDefault(locale)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(locale)
        cfg.setLayoutDirection(locale)
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        emptyView = findViewById(R.id.emptyView)
        countView = findViewById(R.id.docCount)
        findViewById<ListView>(R.id.docList).adapter = adapter
        findViewById<View>(R.id.btnScan).setOnClickListener { startScan() }
        setupLanguageToggle()
        refresh()
    }

    private fun isArabic(): Boolean = resources.configuration.locales[0].language == "ar"

    private fun setupLanguageToggle() {
        val ar = findViewById<TextView>(R.id.langAr)
        val fr = findViewById<TextView>(R.id.langFr)
        val arabic = isArabic()
        mark(ar, arabic)
        mark(fr, !arabic)
        ar.setOnClickListener { if (!arabic) setLanguage("ar") }
        fr.setOnClickListener { if (arabic) setLanguage("fr") }
    }

    private fun mark(v: TextView, on: Boolean) {
        v.setBackgroundResource(if (on) R.drawable.bg_lang_on else 0)
        v.setTextColor(getColor(if (on) R.color.navy else R.color.white))
    }

    private fun setLanguage(lang: String) {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LANG, lang).apply()
        recreate()
    }

    private fun startScan() {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(100)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options).getStartScanIntent(this)
            .addOnSuccessListener { launcher.launch(IntentSenderRequest.Builder(it).build()) }
            .addOnFailureListener { Toast.makeText(this, R.string.error, Toast.LENGTH_LONG).show() }
    }

    private fun refresh() {
        files = dir.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".pdf", true) }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
        adapter.clear()
        adapter.addAll(files)
        adapter.notifyDataSetChanged()
        emptyView.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
        countView.text = files.size.toString()
    }

    private fun meta(f: File): String {
        val date = SimpleDateFormat("dd/MM/yyyy  HH:mm", Locale.US).format(Date(f.lastModified()))
        val kb = f.length() / 1024.0
        val size = if (kb >= 1024) {
            String.format(Locale.US, "%.1f %s", kb / 1024.0, getString(R.string.unit_mb))
        } else {
            String.format(Locale.US, "%d %s", maxOf(1L, Math.round(kb)), getString(R.string.unit_kb))
        }
        return "$date  •  $size"
    }

    private fun uriOf(f: File) = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)

    private fun openPdf(f: File) {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uriOf(f), "application/pdf")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { startActivity(i) } catch (e: Exception) { sharePdf(f) }
    }

    private fun sharePdf(f: File) {
        val i = Intent(Intent.ACTION_SEND).setType("application/pdf")
            .putExtra(Intent.EXTRA_STREAM, uriOf(f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, getString(R.string.chooser)))
    }

    private fun confirmDelete(f: File) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_title)
            .setMessage(f.name)
            .setPositiveButton(R.string.delete) { _, _ -> f.delete(); refresh() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private inner class DocAdapter : ArrayAdapter<File>(this@MainActivity, 0, ArrayList<File>()) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_doc, parent, false)
            val f = getItem(position) ?: return v
            v.findViewById<TextView>(R.id.docName).text = f.name
            v.findViewById<TextView>(R.id.docMeta).text = meta(f)
            v.findViewById<View>(R.id.docCard).setOnClickListener { openPdf(f) }
            v.findViewById<View>(R.id.docShare).setOnClickListener { sharePdf(f) }
            v.findViewById<View>(R.id.docDelete).setOnClickListener { confirmDelete(f) }
            return v
        }
    }

    companion object {
        private const val PREFS = "safha"
        private const val KEY_LANG = "lang"
    }
}
