package com.fegt.docscanner

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import java.io.File

object ScanHelper {
    fun start(
        activity: Activity, pageLimit: Int,
        launcher: ActivityResultLauncher<IntentSenderRequest>, onFail: () -> Unit
    ) {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(pageLimit)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options).getStartScanIntent(activity)
            .addOnSuccessListener { launcher.launch(IntentSenderRequest.Builder(it).build()) }
            .addOnFailureListener { onFail() }
    }

    fun uris(data: Intent?): List<Uri> {
        val r = GmsDocumentScanningResult.fromActivityResultIntent(data) ?: return emptyList()
        val pages = r.pages ?: return emptyList()
        val out = ArrayList<Uri>()
        for (p in pages) out.add(p.imageUri)
        return out
    }
}

object Ingest {
    const val DOC = 0
    const val BOOK = 1
    const val BOARD = 2
    const val EXAM = 3

    /** Scanner temp files are private copies: remove them once imported. */
    fun discard(u: Uri) {
        try {
            if (u.scheme == "file") {
                val p = u.path
                if (p != null) File(p).delete()
            }
        } catch (e: Exception) { }
    }

    /** Off the UI thread only. Returns the number of pages added. [index] < 0 appends. */
    fun addUris(ctx: Context, d: Doc, uris: List<Uri>, preset: Int, bookRtl: Boolean, index: Int): Int {
        var at = index
        var added = 0
        for (u in uris) {
            val src = Img.decodeUri(ctx, u, DocStore.MAX_SIDE)
            discard(u)
            if (src == null) continue
            if (preset == BOOK) {
                val halves = ImageOps.splitHalves(src)
                val first = if (bookRtl) halves.second else halves.first
                val second = if (bookRtl) halves.first else halves.second
                DocStore.addPage(ctx, d, first, at)
                if (at >= 0) at++
                DocStore.addPage(ctx, d, second, at)
                if (at >= 0) at++
                added += 2
            } else {
                val b = if (preset == BOARD || preset == EXAM) ImageOps.magic(src) else src
                DocStore.addPage(ctx, d, b, at)
                if (at >= 0) at++
                added++
            }
        }
        return added
    }

    /** Off the UI thread only. */
    fun addPdf(ctx: Context, d: Doc, uri: Uri, index: Int): Int {
        var at = index
        return PdfImport.render(ctx, uri) { bmp ->
            DocStore.addPage(ctx, d, bmp, at)
            if (at >= 0) at++
        }
    }
}
