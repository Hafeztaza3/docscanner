package com.fegt.docscanner

import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.io.File

class OcrActivity : BaseActivity() {

    private lateinit var doc: Doc
    private lateinit var ocrText: EditText
    private lateinit var trText: EditText
    private lateinit var status: TextView
    private lateinit var trStatus: TextView
    private lateinit var progress: ProgressBar
    private lateinit var langSpinner: Spinner
    private lateinit var trFrom: Spinner
    private lateinit var trTo: Spinner
    private lateinit var btnRun: View
    private lateinit var btnStop: View

    private val ocrCodes = listOf("ara+fra", "ara", "fra")
    private val trCodes = listOf(TranslateLanguage.ARABIC, TranslateLanguage.FRENCH, TranslateLanguage.ENGLISH)

    @Volatile
    private var cancelled = false
    private var running = false
    private var engine: OcrEngine? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("doc")
        val d = if (id == null) null else DocStore.load(this, id)
        if (d == null) {
            finish()
            return
        }
        doc = d
        if (doc.kind == "id") window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_ocr)
        bar(R.string.ocr_title) { finish() }
        ocrText = findViewById(R.id.ocrText)
        trText = findViewById(R.id.trText)
        status = findViewById(R.id.ocrStatus)
        trStatus = findViewById(R.id.trStatus)
        progress = findViewById(R.id.ocrProgress)
        langSpinner = findViewById(R.id.ocrLang)
        trFrom = findViewById(R.id.trFrom)
        trTo = findViewById(R.id.trTo)
        btnRun = findViewById(R.id.btnOcrRun)
        btnStop = findViewById(R.id.btnOcrStop)

        langSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf(getString(R.string.ocr_l_both), getString(R.string.ocr_l_ar), getString(R.string.ocr_l_fr))
        )
        val names = listOf(getString(R.string.lang_name_ar), getString(R.string.lang_name_fr), getString(R.string.lang_name_en))
        trFrom.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        trTo.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        ocrText.setText(doc.text)
        suggestDirection()

        btnRun.setOnClickListener { runOcr() }
        btnStop.setOnClickListener {
            cancelled = true
            engine?.stop()
        }
        findViewById<View>(R.id.btnTranslate).setOnClickListener { translate() }
        buildActions()
    }

    private fun suggestDirection() {
        val arabic = Util.hasArabic(ocrText.text.toString()) || (ocrText.text.isEmpty() && isArabic())
        trFrom.setSelection(if (arabic) 0 else 1)
        trTo.setSelection(if (arabic) 1 else 0)
    }

    private fun buildActions() {
        val navy = getColor(R.color.navy)
        val a = findViewById<LinearLayout>(R.id.ocrActions)
        a.addView(Ui.tile(this, R.drawable.ic_copy, R.string.copy, navy, true, true) {
            Util.copy(this, ocrText.text.toString())
            toast(R.string.copied)
        })
        a.addView(Ui.tile(this, R.drawable.ic_share, R.string.ocr_txt, navy, true, true) {
            shareTxt(ocrText.text.toString())
        })
        a.addView(Ui.tile(this, R.drawable.ic_word, R.string.ocr_word, navy, true, true) {
            shareDocx(ocrText.text.toString())
        })
        a.addView(Ui.tile(this, R.drawable.ic_check, R.string.save, navy, true, true) {
            saveText()
            toast(R.string.ocr_saved)
        })
        val t = findViewById<LinearLayout>(R.id.trActions)
        t.addView(Ui.tile(this, R.drawable.ic_copy, R.string.copy, navy, true, true) {
            Util.copy(this, trText.text.toString())
            toast(R.string.copied)
        })
        t.addView(Ui.tile(this, R.drawable.ic_share, R.string.ocr_txt, navy, true, true) {
            shareTxt(trText.text.toString())
        })
        t.addView(Ui.tile(this, R.drawable.ic_word, R.string.ocr_word, navy, true, true) {
            shareDocx(trText.text.toString())
        })
    }

    // ---------- OCR ----------

    private fun runOcr() {
        if (running || doc.pages.isEmpty()) return
        running = true
        cancelled = false
        btnRun.visibility = View.GONE
        btnStop.visibility = View.VISIBLE
        progress.visibility = View.VISIBLE
        progress.max = doc.pages.size
        progress.progress = 0
        status.setText(R.string.ocr_init)
        val codes = ocrCodes[langSpinner.selectedItemPosition]
        val names = ArrayList(doc.pages)
        inBg {
            val eng = OcrEngine(this)
            engine = eng
            val ok = eng.open(codes)
            if (!ok) {
                eng.close()
                onUi { finishRun(R.string.ocr_fail) }
            } else {
                val sb = StringBuilder()
                var failed = false
                for (i in names.indices) {
                    if (cancelled) break
                    val pageNo = i + 1
                    onUi {
                        status.text = getString(R.string.ocr_progress, pageNo, names.size)
                        progress.progress = i
                    }
                    try {
                        val bmp = Img.decodeFile(DocStore.pageFile(this, doc, names[i]), DocStore.MAX_SIDE)
                        if (bmp != null) {
                            val t = eng.recognize(ImageOps.magic(bmp))
                            if (t.isNotEmpty()) {
                                if (sb.isNotEmpty()) sb.append("\n\n")
                                sb.append(t)
                                val snapshot = sb.toString()
                                onUi { ocrText.setText(snapshot) }
                            }
                        }
                    } catch (e: Exception) {
                        failed = true
                    } catch (e: OutOfMemoryError) {
                        failed = true
                    }
                }
                eng.close()
                engine = null
                val empty = sb.isEmpty()
                val wasCancelled = cancelled
                onUi {
                    if (!empty) {
                        ocrText.setText(sb.toString())
                        saveText()
                        suggestDirection()
                    }
                    when {
                        failed -> finishRun(R.string.ocr_fail)
                        empty && !wasCancelled -> finishRun(R.string.ocr_empty)
                        else -> finishRun(0)
                    }
                }
            }
        }
    }

    private fun finishRun(msg: Int) {
        running = false
        btnRun.visibility = View.VISIBLE
        btnStop.visibility = View.GONE
        progress.visibility = View.GONE
        if (msg == 0) status.text = "" else status.setText(msg)
    }

    private fun saveText() {
        val d = DocStore.load(this, doc.id) ?: return
        d.text = ocrText.text.toString()
        DocStore.save(this, d)
    }

    override fun onPause() {
        super.onPause()
        if (::ocrText.isInitialized && !running) saveText()
    }

    override fun onDestroy() {
        cancelled = true
        engine?.stop()
        super.onDestroy()
    }

    // ---------- export ----------

    private fun fileBase(): String = Util.safeName(doc.title)

    private fun shareTxt(text: String) {
        if (text.isBlank()) return
        runBusy(R.string.exporting, {
            val f = File(Util.exportsDir(this), fileBase() + ".txt")
            f.writeText(text, Charsets.UTF_8)
            f
        }) { f -> Util.share(this, f, "text/plain", getString(R.string.share)) }
    }

    private fun shareDocx(text: String) {
        if (text.isBlank()) return
        runBusy(R.string.exporting, {
            val f = File(Util.exportsDir(this), fileBase() + ".docx")
            DocxWriter.write(f, text)
            f
        }) { f ->
            Util.share(
                this, f, "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                getString(R.string.share)
            )
        }
    }

    // ---------- translation ----------

    private fun translate() {
        val text = ocrText.text.toString()
        if (text.isBlank()) return
        val src = trCodes[trFrom.selectedItemPosition]
        val dst = trCodes[trTo.selectedItemPosition]
        if (src == dst) {
            trText.setText(text)
            return
        }
        val tr = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build()
        )
        trStatus.setText(R.string.tr_wait)
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                tr.translate(text)
                    .addOnSuccessListener { out ->
                        trText.setText(out)
                        trStatus.text = ""
                        tr.close()
                    }
                    .addOnFailureListener {
                        trStatus.setText(R.string.tr_fail)
                        tr.close()
                    }
            }
            .addOnFailureListener {
                trStatus.setText(R.string.tr_fail)
                tr.close()
            }
    }
}
