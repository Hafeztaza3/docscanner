package com.fegt.docscanner

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning

class MainActivity : BaseActivity() {

    private var all: List<Doc> = emptyList()
    private val shown = ArrayList<Doc>()
    private val adapter = DocAdapter()
    private lateinit var countView: TextView
    private lateinit var emptyView: View
    private lateinit var searchBox: EditText
    private var pendingPreset = Ingest.DOC
    private var pendingRtl = false

    private val scanLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { r ->
        if (r.resultCode == RESULT_OK) {
            val uris = ScanHelper.uris(r.data)
            if (uris.isNotEmpty()) createFromUris(uris, pendingPreset, pendingRtl, presetTitle(pendingPreset))
        }
    }

    private val pickImages = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) createFromUris(uris, Ingest.DOC, false, getString(R.string.tile_images))
    }

    private val pickPdfs = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) createFromPdfs(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val list = findViewById<ListView>(R.id.docList)
        val header = LayoutInflater.from(this).inflate(R.layout.header_main, list, false)
        list.addHeaderView(header, null, false)
        list.adapter = adapter
        countView = header.findViewById(R.id.docCount)
        emptyView = header.findViewById(R.id.emptyView)
        searchBox = header.findViewById(R.id.searchBox)
        header.findViewById<View>(R.id.btnScan).setOnClickListener { startScan(Ingest.DOC) }
        buildTools(header.findViewById(R.id.toolsGrid))
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })
        setupLanguageToggle()
        Bg.pool.execute { Util.clearExports(this) }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------- tools ----------

    private fun buildTools(grid: LinearLayout) {
        val navy = getColor(R.color.navy)
        val rows = listOf(
            listOf(
                Triple(R.drawable.ic_id, R.string.tile_id, { startActivity(Intent(this, IdCardActivity::class.java)) }),
                Triple(R.drawable.ic_book, R.string.tile_book, { askBookOrder() }),
                Triple(R.drawable.ic_board, R.string.tile_board, { startScan(Ingest.BOARD) }),
                Triple(R.drawable.ic_exam, R.string.tile_exam, { startScan(Ingest.EXAM) })
            ),
            listOf(
                Triple(R.drawable.ic_image, R.string.tile_images, { pickImages.launch("image/*") }),
                Triple(R.drawable.ic_pdf, R.string.tile_pdf, { pickPdfs.launch("application/pdf") }),
                Triple(R.drawable.ic_qr, R.string.tile_qr, { scanCode() }),
                Triple(R.drawable.ic_sign, R.string.tile_sign, { Signature.showPad(this) { toast(R.string.sign_saved) } })
            )
        )
        for (row in rows) {
            val ll = LinearLayout(this)
            ll.orientation = LinearLayout.HORIZONTAL
            for (t in row) {
                ll.addView(Ui.tile(this, t.first, t.second, navy, true, true, t.third))
            }
            grid.addView(ll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun presetTitle(p: Int): String {
        val base = when (p) {
            Ingest.BOOK -> getString(R.string.tile_book)
            Ingest.BOARD -> getString(R.string.tile_board)
            Ingest.EXAM -> getString(R.string.tile_exam)
            else -> getString(R.string.tile_images)
        }
        return base
    }

    private fun askBookOrder() {
        Ui.choose(
            this, getString(R.string.book_order_title),
            listOf(getString(R.string.book_ltr), getString(R.string.book_rtl))
        ) { which ->
            pendingRtl = which == 1
            startScan(Ingest.BOOK)
        }
    }

    private fun startScan(preset: Int) {
        pendingPreset = preset
        ScanHelper.start(this, 100, scanLauncher) { toast(R.string.error_scanner) }
    }

    private fun scanCode() {
        GmsBarcodeScanning.getClient(this).startScan()
            .addOnSuccessListener { b ->
                val v = b.rawValue ?: b.displayValue ?: ""
                if (v.isNotEmpty()) showCode(v)
            }
            .addOnFailureListener { toast(R.string.qr_fail) }
    }

    private fun showCode(v: String) {
        val b = AlertDialog.Builder(this)
            .setTitle(R.string.qr_title)
            .setMessage(v)
            .setPositiveButton(R.string.qr_copy) { _, _ ->
                Util.copy(this, v)
                toast(R.string.copied)
            }
            .setNeutralButton(R.string.share) { _, _ -> Util.shareText(this, v, getString(R.string.share)) }
        if (v.startsWith("http://") || v.startsWith("https://")) {
            b.setNegativeButton(R.string.qr_open) { _, _ ->
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(v)))
                } catch (e: Exception) {
                    toast(R.string.error)
                }
            }
        } else {
            b.setNegativeButton(R.string.cancel, null)
        }
        b.show()
    }

    // ---------- creating documents ----------

    private fun newTitle(base: String): String = base + "  " + Util.date(System.currentTimeMillis())

    private fun createFromUris(uris: List<Uri>, preset: Int, rtl: Boolean, base: String) {
        runBusy(R.string.busy, {
            val d = DocStore.create(this, newTitle(base), "scan")
            val n = Ingest.addUris(this, d, uris, preset, rtl, -1)
            if (n == 0) {
                DocStore.delete(this, d.id)
                ""
            } else {
                DocStore.save(this, d)
                d.id
            }
        }) { id ->
            if (id.isEmpty()) toast(R.string.import_none) else openDoc(id)
        }
    }

    private fun createFromPdfs(uris: List<Uri>) {
        runBusy(R.string.busy, {
            val d = DocStore.create(this, newTitle(getString(R.string.tile_pdf)), "scan")
            var n = 0
            for (u in uris) n += Ingest.addPdf(this, d, u, -1)
            if (n == 0) {
                DocStore.delete(this, d.id)
                ""
            } else {
                DocStore.save(this, d)
                d.id
            }
        }) { id ->
            if (id.isEmpty()) toast(R.string.import_pdf_fail) else openDoc(id)
        }
    }

    private fun openDoc(id: String) {
        startActivity(Intent(this, DocActivity::class.java).putExtra("doc", id))
    }

    // ---------- list ----------

    private fun refresh() {
        all = DocStore.list(this)
        applyFilter()
    }

    private fun applyFilter() {
        val q = searchBox.text.toString().trim()
        shown.clear()
        for (d in all) {
            if (q.isEmpty() || d.title.contains(q, true) || d.text.contains(q, true)) shown.add(d)
        }
        adapter.notifyDataSetChanged()
        countView.text = shown.size.toString()
        emptyView.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        val title = emptyView.findViewById<TextView>(R.id.emptyTitle)
        val hint = emptyView.findViewById<TextView>(R.id.emptyHint)
        if (all.isEmpty()) {
            title.setText(R.string.empty_title)
            hint.setText(R.string.empty_hint)
            hint.visibility = View.VISIBLE
        } else {
            title.setText(R.string.no_result)
            hint.visibility = View.GONE
        }
    }

    private fun meta(d: Doc): String =
        Util.date(d.updated) + "  •  " + getString(R.string.pages_count, d.pages.size)

    private fun confirmDelete(d: Doc) {
        Ui.confirm(this, R.string.delete_title, d.title, R.string.delete) {
            DocStore.delete(this, d.id)
            refresh()
        }
    }

    private inner class DocAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: LayoutInflater.from(this@MainActivity).inflate(R.layout.item_doc, parent, false)
            val d = shown[position]
            val thumb = v.findViewById<ImageView>(R.id.docThumb)
            if (d.pages.isNotEmpty()) {
                Thumbs.load(thumb, DocStore.pageFile(this@MainActivity, d, d.pages[0]), 220)
            } else {
                thumb.tag = null
                thumb.setImageDrawable(null)
            }
            v.findViewById<TextView>(R.id.docName).text = d.title
            v.findViewById<TextView>(R.id.docMeta).text = meta(d)
            v.findViewById<View>(R.id.docCard).setOnClickListener { openDoc(d.id) }
            v.findViewById<View>(R.id.docShare).setOnClickListener { sharePdfOf(d) }
            v.findViewById<View>(R.id.docDelete).setOnClickListener { confirmDelete(d) }
            return v
        }
    }

    // ---------- language ----------

    private fun setupLanguageToggle() {
        val ar = findViewById<TextView>(R.id.langAr)
        val fr = findViewById<TextView>(R.id.langFr)
        val arabic = isArabic()
        mark(ar, arabic)
        mark(fr, !arabic)
        ar.setOnClickListener { if (!arabic) setLanguage("ar") }
        fr.setOnClickListener { if (arabic) setLanguage("fr") }
    }

    private fun mark(v: TextView, on: Boolean) {
        v.setBackgroundResource(if (on) R.drawable.bg_lang_on else 0)
        v.setTextColor(getColor(if (on) R.color.navy else R.color.white))
    }

    private fun setLanguage(lang: String) {
        getSharedPreferences(Lang.PREFS, Context.MODE_PRIVATE).edit().putString(Lang.KEY, lang).apply()
        recreate()
    }
}
