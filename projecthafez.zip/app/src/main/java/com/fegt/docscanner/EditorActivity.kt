package com.fegt.docscanner

import android.app.AlertDialog
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.io.File

class EditorActivity : BaseActivity() {

    private lateinit var doc: Doc
    private lateinit var pageName: String
    private lateinit var edit: EditView
    private lateinit var panelAdjust: View
    private lateinit var panelErase: View
    private lateinit var panelStamp: View
    private lateinit var chips: ArrayList<TextView>

    private var work: Bitmap? = null          // committed full-resolution page
    private var previewBase: Bitmap? = null   // downscaled copy used for live adjustments
    private val adj = Adjust()
    private val undo = ArrayList<Bitmap>()
    private var dirty = false
    private var gen = 0
    private var panel = 0                     // 0 none, 1 adjust, 2 erase, 3 stamp

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("doc")
        val page = intent.getStringExtra("page")
        val d = if (id == null) null else DocStore.load(this, id)
        if (d == null || page == null || !d.pages.contains(page)) {
            finish()
            return
        }
        doc = d
        pageName = page
        if (doc.kind == "id") window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_editor)
        bar(R.string.ed_title) { confirmExit() }
        barAction(R.id.barAction1, R.drawable.ic_check, R.string.save) { saveAndFinish() }
        edit = findViewById(R.id.editView)
        panelAdjust = findViewById(R.id.panelAdjust)
        panelErase = findViewById(R.id.panelErase)
        panelStamp = findViewById(R.id.panelStamp)
        buildChips()
        buildTools()
        wireControls()
        loadPage()
    }

    private fun pageFile(): File = DocStore.pageFile(this, doc, pageName)

    private fun loadPage() {
        inBg {
            val b = Img.decodeFile(pageFile(), DocStore.MAX_SIDE)
            onUi {
                if (b == null) {
                    toast(R.string.error)
                    finish()
                } else {
                    setWork(b)
                }
            }
        }
    }

    private fun setWork(b: Bitmap) {
        work = b
        previewBase = Img.limit(b, 1100)
        edit.setImage(previewBase!!)
        requestPreview()
    }

    // ---------- UI building ----------

    private fun buildChips() {
        val row = findViewById<LinearLayout>(R.id.chipRow)
        val names = listOf(R.string.f_original, R.string.f_magic, R.string.f_gray, R.string.f_bw, R.string.f_restore)
        chips = ArrayList()
        for (i in names.indices) {
            val c = Ui.chip(this, getString(names[i]), i == 0)
            c.setOnClickListener {
                adj.filter = i
                for (k in chips.indices) Ui.setChip(this, chips[k], k == i)
                requestPreview()
            }
            chips.add(c)
            row.addView(c)
        }
    }

    private fun buildTools() {
        val row = findViewById<LinearLayout>(R.id.toolRow)
        val navy = getColor(R.color.navy)
        row.addView(Ui.tile(this, R.drawable.ic_tune, R.string.ed_adjust, navy, false, false) { showPanel(if (panel == 1) 0 else 1) })
        row.addView(Ui.tile(this, R.drawable.ic_rotate_l, R.string.ed_rot_l, navy, false, false) { rotate(-90) })
        row.addView(Ui.tile(this, R.drawable.ic_rotate_r, R.string.ed_rot_r, navy, false, false) { rotate(90) })
        row.addView(Ui.tile(this, R.drawable.ic_eraser, R.string.ed_eraser, navy, false, false) { showPanel(if (panel == 2) 0 else 2) })
        row.addView(Ui.tile(this, R.drawable.ic_sign, R.string.ed_sign, navy, false, false) { beginStamp() })
        row.addView(Ui.tile(this, R.drawable.ic_drop, R.string.ed_wm, navy, false, false) { watermark() })
        row.addView(Ui.tile(this, R.drawable.ic_undo, R.string.ed_undo, navy, false, false) { undoLast() })
        row.addView(Ui.tile(this, R.drawable.ic_replace, R.string.ed_orig, navy, false, false) { restoreOriginal() })
    }

    private fun seek(id: Int, onChange: (Int) -> Unit) {
        findViewById<SeekBar>(id).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) onChange(progress)
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    private fun wireControls() {
        seek(R.id.sbBright) { p -> adj.brightness = p - 100; requestPreview() }
        seek(R.id.sbContrast) { p -> adj.contrast = p - 100; requestPreview() }
        seek(R.id.sbSharp) { p -> adj.sharpen = p; requestPreview() }
        seek(R.id.sbBrush) { p -> edit.brushFrac = 0.01f + p / 100f * 0.07f }
        edit.brushFrac = 0.01f + 30 / 100f * 0.07f
        findViewById<CheckBox>(R.id.cbDenoise).setOnCheckedChangeListener { _, checked ->
            adj.denoise = checked
            requestPreview()
        }
        findViewById<View>(R.id.btnApplyAdjust).setOnClickListener { commitAdjust(null) }
        findViewById<View>(R.id.btnClearStrokes).setOnClickListener { edit.clearStrokes() }
        findViewById<View>(R.id.btnApplyErase).setOnClickListener { applyErase() }
        findViewById<View>(R.id.btnCancelStamp).setOnClickListener {
            edit.stopStamp()
            showPanel(0)
        }
        findViewById<View>(R.id.btnApplyStamp).setOnClickListener { applyStamp() }
    }

    private fun showPanel(p: Int) {
        panel = p
        panelAdjust.visibility = if (p == 1) View.VISIBLE else View.GONE
        panelErase.visibility = if (p == 2) View.VISIBLE else View.GONE
        panelStamp.visibility = if (p == 3) View.VISIBLE else View.GONE
        if (p != 3) edit.stopStamp()
        edit.mode = if (p == 2) EditView.MODE_ERASE else if (p == 3) EditView.MODE_STAMP else EditView.MODE_VIEW
        if (p != 2) edit.clearStrokes()
    }

    // ---------- live preview ----------

    private fun requestPreview() {
        val base = previewBase ?: return
        val my = ++gen
        val a = adj.copyOf()
        inBg {
            val out = try { ImageOps.apply(base, a) } catch (e: OutOfMemoryError) { base }
            onUi { if (my == gen) edit.setImage(out) }
        }
    }

    private fun push(b: Bitmap) {
        undo.add(b)
        while (undo.size > 3) undo.removeAt(0)
    }

    private fun resetAdjust() {
        adj.filter = 0
        adj.brightness = 0
        adj.contrast = 0
        adj.sharpen = 0
        adj.denoise = false
        for (k in chips.indices) Ui.setChip(this, chips[k], k == 0)
        findViewById<SeekBar>(R.id.sbBright).progress = 100
        findViewById<SeekBar>(R.id.sbContrast).progress = 100
        findViewById<SeekBar>(R.id.sbSharp).progress = 0
        findViewById<CheckBox>(R.id.cbDenoise).isChecked = false
    }

    // ---------- operations ----------

    /** Bakes the pending adjustments into the page. [then] runs on the UI thread afterwards. */
    private fun commitAdjust(then: (() -> Unit)?) {
        val w = work ?: return
        if (adj.isIdentity()) {
            then?.invoke()
            return
        }
        val a = adj.copyOf()
        runBusy(R.string.busy, { ImageOps.apply(w, a) }) { out ->
            push(w)
            dirty = true
            resetAdjust()
            setWork(out)
            then?.invoke()
        }
    }

    private fun rotate(deg: Int) {
        val w = work ?: return
        val pb = previewBase ?: return
        runBusy(R.string.busy, { Pair(ImageOps.rotate(w, deg), ImageOps.rotate(pb, deg)) }) { r ->
            push(w)
            dirty = true
            work = r.first
            previewBase = r.second
            edit.setImage(r.second)
            requestPreview()
        }
    }

    private fun applyErase() {
        val w = work ?: return
        if (!edit.hasStrokes()) return
        val strokes = edit.strokeList()
        val frac = edit.brushFrac
        runBusy(R.string.busy, { ImageOps.eraseStrokes(w, strokes, frac) }) { out ->
            push(w)
            dirty = true
            edit.clearStrokes()
            work = out
            previewBase = Img.limit(out, 1100)
            edit.setImage(previewBase!!)
            requestPreview()
        }
    }

    private fun beginStamp() {
        val o = Signature.load(this)
        if (o == null) {
            Signature.showPad(this) { beginStamp() }
            return
        }
        showPanel(3)
        edit.startStamp(o)
    }

    private fun applyStamp() {
        val w = work ?: return
        val o = Signature.load(this) ?: return
        val cx = edit.stampCx()
        val cy = edit.stampCy()
        val wf = edit.stampW()
        runBusy(R.string.busy, { ImageOps.stamp(w, o, cx, cy, wf) }) { out ->
            push(w)
            dirty = true
            edit.stopStamp()
            showPanel(0)
            work = out
            previewBase = Img.limit(out, 1100)
            edit.setImage(previewBase!!)
            requestPreview()
        }
    }

    private fun watermark() {
        val w = work ?: return
        Ui.prompt(this, R.string.wm_title, "", R.string.wm_hint) { text ->
            if (text.isNotEmpty()) {
                runBusy(R.string.busy, { ImageOps.watermark(w, text, 25) }) { out ->
                    push(w)
                    dirty = true
                    work = out
                    previewBase = Img.limit(out, 1100)
                    edit.setImage(previewBase!!)
                    requestPreview()
                }
            }
        }
    }

    private fun undoLast() {
        if (undo.isEmpty()) {
            toast(R.string.ed_nothing)
            return
        }
        val prev = undo.removeAt(undo.size - 1)
        setWork(prev)
        dirty = true
    }

    private fun restoreOriginal() {
        val of = DocStore.origFile(this, doc, pageName)
        if (!of.exists()) {
            toast(R.string.ed_nothing)
            return
        }
        Ui.confirm(this, R.string.ed_orig, getString(R.string.ed_restored), R.string.ok) {
            inBg {
                of.copyTo(pageFile(), true)
                val b = Img.decodeFile(pageFile(), DocStore.MAX_SIDE)
                onUi {
                    if (b != null) {
                        undo.clear()
                        resetAdjust()
                        setWork(b)
                        dirty = false
                        setResult(RESULT_OK)
                        toast(R.string.ed_restored)
                    }
                }
            }
        }
    }

    // ---------- leaving ----------

    private fun saveAndFinish() {
        commitAdjust {
            val w = work
            if (w == null) {
                finish()
            } else if (!dirty) {
                finish()
            } else {
                runBusy(R.string.busy, {
                    val pf = pageFile()
                    val of = DocStore.origFile(this, doc, pageName)
                    if (!of.exists()) pf.copyTo(of, true)
                    DocStore.writeJpeg(pf, w, 92)
                    true
                }) { _ ->
                    setResult(RESULT_OK)
                    toast(R.string.ed_saved)
                    finish()
                }
            }
        }
    }

    private fun confirmExit() {
        if (!dirty && adj.isIdentity()) {
            finish()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.ed_unsaved_title)
            .setPositiveButton(R.string.ed_discard) { _, _ -> finish() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    override fun onBackPressed() {
        confirmExit()
    }
}
