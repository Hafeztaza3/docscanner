package com.fegt.docscanner

import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

/** Shows one page, lets the user paint an eraser mask or place/resize a signature overlay. */
class EditView(ctx: Context, attrs: AttributeSet?) : View(ctx, attrs) {

    companion object {
        const val MODE_VIEW = 0
        const val MODE_ERASE = 1
        const val MODE_STAMP = 2
    }

    private var bitmap: Bitmap? = null
    private val dst = RectF()
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokes = ArrayList<Path>()
    private var current: Path? = null

    private var overlay: Bitmap? = null
    private var cx = 0.5f
    private var cy = 0.75f
    private var wFrac = 0.3f
    private var lastX = 0f
    private var lastY = 0f

    var mode: Int = MODE_VIEW
        set(v) {
            field = v
            invalidate()
        }

    var brushFrac: Float = 0.03f
        set(v) {
            field = v
            invalidate()
        }

    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            wFrac = (wFrac * detector.scaleFactor).coerceIn(0.05f, 0.9f)
            invalidate()
            return true
        }
    })

    init {
        strokePaint.style = Paint.Style.STROKE
        strokePaint.strokeCap = Paint.Cap.ROUND
        strokePaint.strokeJoin = Paint.Join.ROUND
        strokePaint.color = Color.argb(150, 220, 30, 60)
    }

    fun setImage(b: Bitmap) {
        bitmap = b
        invalidate()
    }

    fun clearStrokes() {
        strokes.clear()
        current = null
        invalidate()
    }

    fun hasStrokes(): Boolean = strokes.isNotEmpty()

    fun strokeList(): List<Path> = ArrayList(strokes)

    fun startStamp(o: Bitmap) {
        overlay = o
        cx = 0.5f
        cy = 0.75f
        wFrac = 0.3f
        mode = MODE_STAMP
    }

    fun stopStamp() {
        overlay = null
        mode = MODE_VIEW
    }

    fun stampCx(): Float = cx
    fun stampCy(): Float = cy
    fun stampW(): Float = wFrac

    private fun layoutRect() {
        val b = bitmap ?: return
        val vw = width.toFloat()
        val vh = height.toFloat()
        val s = minOf(vw / b.width, vh / b.height)
        val dw = b.width * s
        val dh = b.height * s
        val l = (vw - dw) / 2f
        val t = (vh - dh) / 2f
        dst.set(l, t, l + dw, t + dh)
    }

    override fun onDraw(canvas: Canvas) {
        val b = bitmap ?: return
        layoutRect()
        canvas.drawBitmap(b, null, dst, bmpPaint)
        if (mode == MODE_ERASE && strokes.isNotEmpty()) {
            val m = Matrix()
            m.setScale(dst.width(), dst.height())
            m.postTranslate(dst.left, dst.top)
            strokePaint.strokeWidth = maxOf(2f, brushFrac * dst.width())
            for (s in strokes) {
                val p = Path()
                s.transform(m, p)
                canvas.drawPath(p, strokePaint)
            }
        }
        val o = overlay
        if (mode == MODE_STAMP && o != null) {
            val dw = wFrac * dst.width()
            val dh = dw * o.height / o.width
            val l = dst.left + cx * dst.width() - dw / 2f
            val t = dst.top + cy * dst.height() - dh / 2f
            canvas.drawBitmap(o, null, RectF(l, t, l + dw, t + dh), bmpPaint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (bitmap == null || dst.width() <= 0f) return false
        if (mode == MODE_ERASE) {
            val nx = (e.x - dst.left) / dst.width()
            val ny = (e.y - dst.top) / dst.height()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val p = Path()
                    p.moveTo(nx, ny)
                    p.lineTo(nx + 0.0001f, ny)
                    strokes.add(p)
                    current = p
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                MotionEvent.ACTION_MOVE -> current?.lineTo(nx, ny)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> current = null
            }
            invalidate()
            return true
        }
        if (mode == MODE_STAMP) {
            scaler.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = e.x
                    lastY = e.y
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!scaler.isInProgress && e.pointerCount == 1) {
                        cx += (e.x - lastX) / dst.width()
                        cy += (e.y - lastY) / dst.height()
                        cx = cx.coerceIn(0f, 1f)
                        cy = cy.coerceIn(0f, 1f)
                        lastX = e.x
                        lastY = e.y
                        invalidate()
                    }
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    val idx = if (e.actionIndex == 0) 1 else 0
                    lastX = e.getX(idx)
                    lastY = e.getY(idx)
                }
            }
            return true
        }
        return false
    }
}

class SignaturePad(ctx: Context) : View(ctx) {
    private val strokes = ArrayList<Path>()
    private var current: Path? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.color = Color.rgb(10, 30, 110)
        paint.strokeWidth = Util.dp(ctx, 3).toFloat()
    }

    fun clear() {
        strokes.clear()
        current = null
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        for (p in strokes) canvas.drawPath(p, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val p = Path()
                p.moveTo(e.x, e.y)
                p.lineTo(e.x + 0.1f, e.y)
                strokes.add(p)
                current = p
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> current?.lineTo(e.x, e.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> current = null
        }
        invalidate()
        return true
    }

    /** Transparent bitmap cropped to the ink, or null if nothing was drawn. */
    fun toBitmap(): Bitmap? {
        if (strokes.isEmpty()) return null
        val rf = RectF()
        var first = true
        for (p in strokes) {
            val r = RectF()
            p.computeBounds(r, true)
            if (first) { rf.set(r); first = false } else rf.union(r)
        }
        val pad = paint.strokeWidth * 2f
        rf.inset(-pad, -pad)
        val w = maxOf(8, Math.ceil(rf.width().toDouble()).toInt())
        val h = maxOf(8, Math.ceil(rf.height().toDouble()).toInt())
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.translate(-rf.left, -rf.top)
        for (p in strokes) c.drawPath(p, paint)
        return bmp
    }
}

object Signature {
    fun file(ctx: Context): File = File(ctx.filesDir, "signature.png")

    fun exists(ctx: Context): Boolean = file(ctx).exists()

    fun load(ctx: Context): Bitmap? {
        val f = file(ctx)
        return if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
    }

    fun showPad(ctx: Context, onSaved: () -> Unit) {
        val pad = SignaturePad(ctx)
        pad.setBackgroundResource(R.drawable.bg_input)
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val p = Util.dp(ctx, 16)
        box.setPadding(p, p, p, 0)
        val hint = TextView(ctx)
        hint.setText(R.string.sign_hint)
        hint.textSize = 13f
        box.addView(hint)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Util.dp(ctx, 200))
        lp.topMargin = Util.dp(ctx, 8)
        box.addView(pad, lp)
        val dlg = AlertDialog.Builder(ctx)
            .setTitle(R.string.sign_title)
            .setView(box)
            .setPositiveButton(R.string.save, null)
            .setNegativeButton(R.string.cancel, null)
            .setNeutralButton(R.string.sign_clear, null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val b = pad.toBitmap()
            if (b == null) {
                Toast.makeText(ctx, R.string.sign_empty, Toast.LENGTH_SHORT).show()
            } else {
                FileOutputStream(file(ctx)).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
                dlg.dismiss()
                onSaved()
            }
        }
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { pad.clear() }
    }
}
