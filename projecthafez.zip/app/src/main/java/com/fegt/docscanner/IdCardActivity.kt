package com.fegt.docscanner

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts

class IdSpec(val nameRes: Int, val wMm: Float, val hMm: Float, val sides: Int, val custom: Boolean)

class IdCardActivity : BaseActivity() {

    private val specs = listOf(
        IdSpec(R.string.id_cnie, 85.6f, 54f, 2, false),
        IdSpec(R.string.id_permis, 85.6f, 54f, 2, false),
        IdSpec(R.string.id_passport, 125f, 88f, 1, false),
        IdSpec(R.string.id_bank, 85.6f, 54f, 2, false),
        IdSpec(R.string.id_other, 0f, 0f, 1, true)
    )

    private lateinit var typeSpinner: Spinner
    private lateinit var customRow: View
    private lateinit var idW: EditText
    private lateinit var idH: EditText
    private lateinit var twoSides: CheckBox
    private lateinit var sideB: View
    private lateinit var prevA: ImageView
    private lateinit var prevB: ImageView
    private lateinit var labelA: TextView
    private lateinit var labelB: TextView
    private lateinit var statusA: TextView
    private lateinit var statusB: TextView
    private lateinit var btnA: TextView
    private lateinit var btnB: TextView
    private lateinit var mark: EditText

    private var bmpA: Bitmap? = null
    private var bmpB: Bitmap? = null
    private var scanningSide = 0

    private val scanLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { r ->
        if (r.resultCode == RESULT_OK) {
            val uris = ScanHelper.uris(r.data)
            if (uris.isNotEmpty()) {
                val side = scanningSide
                runBusy(R.string.busy, {
                    val b = Img.decodeUri(this, uris[0], 1800)
                    Ingest.discard(uris[0])
                    b ?: throw IllegalStateException("decode")
                }) { b ->
                    if (side == 0) bmpA = b else bmpB = b
                    updateSides()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_idcard)
        bar(R.string.id_title) { finish() }
        typeSpinner = findViewById(R.id.idType)
        customRow = findViewById(R.id.idCustomRow)
        idW = findViewById(R.id.idW)
        idH = findViewById(R.id.idH)
        twoSides = findViewById(R.id.idTwoSides)
        sideB = findViewById(R.id.idSideB)
        prevA = findViewById(R.id.idPrevA)
        prevB = findViewById(R.id.idPrevB)
        labelA = findViewById(R.id.idLabelA)
        labelB = findViewById(R.id.idLabelB)
        statusA = findViewById(R.id.idStatusA)
        statusB = findViewById(R.id.idStatusB)
        btnA = findViewById(R.id.idBtnA)
        btnB = findViewById(R.id.idBtnB)
        mark = findViewById(R.id.idMark)

        val names = ArrayList<String>()
        for (s in specs) names.add(getString(s.nameRes))
        typeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        typeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                bmpA = null
                bmpB = null
                updateSides()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        twoSides.setOnCheckedChangeListener { _, _ -> updateSides() }
        btnA.setOnClickListener { scan(0) }
        btnB.setOnClickListener { scan(1) }
        findViewById<View>(R.id.btnIdGenerate).setOnClickListener { generate() }
        updateSides()
    }

    private fun spec(): IdSpec = specs[typeSpinner.selectedItemPosition]

    private fun sideCount(): Int {
        val s = spec()
        return if (s.custom) (if (twoSides.isChecked) 2 else 1) else s.sides
    }

    private fun updateSides() {
        val s = spec()
        customRow.visibility = if (s.custom) View.VISIBLE else View.GONE
        val n = sideCount()
        sideB.visibility = if (n == 2) View.VISIBLE else View.GONE
        if (n == 2) {
            labelA.setText(R.string.id_front)
            labelB.setText(R.string.id_back)
        } else {
            labelA.setText(if (s.custom) R.string.id_face else R.string.id_page)
        }
        showSide(bmpA, prevA, statusA, btnA)
        showSide(bmpB, prevB, statusB, btnB)
    }

    private fun showSide(b: Bitmap?, iv: ImageView, st: TextView, btn: TextView) {
        if (b == null) {
            iv.setImageDrawable(null)
            st.setText(R.string.id_not_scanned)
            btn.setText(R.string.id_scan_side)
        } else {
            iv.setImageBitmap(b)
            st.setText(R.string.id_scanned)
            btn.setText(R.string.id_rescan)
        }
    }

    private fun scan(side: Int) {
        scanningSide = side
        ScanHelper.start(this, 1, scanLauncher) { toast(R.string.error_scanner) }
    }

    // ---------- A4 composition ----------

    private fun generate() {
        val s = spec()
        val n = sideCount()
        var wMm = s.wMm
        var hMm = s.hMm
        if (s.custom) {
            wMm = Util.num(idW.text.toString())
            hMm = Util.num(idH.text.toString())
        }
        val totalH = hMm * n + (if (n == 2) 14f else 0f)
        if (wMm < 10f || hMm < 10f || wMm > 190f || totalH > 255f) {
            toast(R.string.id_bad_size)
            return
        }
        val a = bmpA
        val b = bmpB
        if (a == null || (n == 2 && b == null)) {
            toast(R.string.id_need_all)
            return
        }
        val markText = mark.text.toString().trim()
        val title = getString(R.string.id_doc_title, getString(s.nameRes)) + "  " + Util.date(System.currentTimeMillis())
        val w = wMm
        val h = hMm
        runBusy(R.string.busy, {
            val sheet = compose(a, if (n == 2) b else null, w, h)
            val finalSheet = if (markText.isNotEmpty()) {
                ImageOps.watermark(sheet, getString(R.string.id_mark_text, markText, Util.today()), 22)
            } else {
                sheet
            }
            val d = DocStore.create(this, title, "id")
            DocStore.addPage(this, d, finalSheet, -1)
            DocStore.save(this, d)
            d.id
        }) { id ->
            bmpA = null
            bmpB = null
            startActivity(Intent(this, DocActivity::class.java).putExtra("doc", id))
            finish()
        }
    }

    /** A4 sheet at 200 dpi with the cards drawn at their real size. */
    private fun compose(a: Bitmap, b: Bitmap?, wMm: Float, hMm: Float): Bitmap {
        val pxMm = 200f / 25.4f
        val pageW = 1654
        val pageH = 2339
        val sheet = Bitmap.createBitmap(pageW, pageH, Bitmap.Config.ARGB_8888)
        val c = Canvas(sheet)
        c.drawColor(Color.WHITE)
        val cw = wMm * pxMm
        val ch = hMm * pxMm
        val left = (pageW - cw) / 2f
        val top1 = 20f * pxMm
        drawCard(c, a, RectF(left, top1, left + cw, top1 + ch))
        if (b != null) {
            val top2 = top1 + ch + 14f * pxMm
            drawCard(c, b, RectF(left, top2, left + cw, top2 + ch))
        }
        return sheet
    }

    private fun drawCard(c: Canvas, src: Bitmap, dst: RectF) {
        var bmp = src
        if ((bmp.width < bmp.height) != (dst.width() < dst.height())) bmp = ImageOps.rotate(bmp, 90)
        c.drawBitmap(bmp, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
        val border = Paint(Paint.ANTI_ALIAS_FLAG)
        border.style = Paint.Style.STROKE
        border.strokeWidth = 2f
        border.color = Color.rgb(192, 198, 208)
        c.drawRect(dst, border)
    }
}
