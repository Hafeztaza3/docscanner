package com.fegt.docscanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Minimal PDF writer: embeds the page JPEGs as-is (DCTDecode), so files stay small. */
object PdfWriter {

    private class Out(val os: OutputStream) {
        var n = 0L
        fun bytes(b: ByteArray) { os.write(b); n += b.size }
        fun str(s: String) = bytes(s.toByteArray(Charsets.ISO_8859_1))
    }

    fun write(target: File, pages: List<File>) {
        val count = pages.size
        val total = 2 + 3 * count
        val offsets = LongArray(total + 1)
        val out = Out(BufferedOutputStream(FileOutputStream(target), 64 * 1024))
        try {
            out.bytes(byteArrayOf(0x25, 0x50, 0x44, 0x46, 0x2D, 0x31, 0x2E, 0x34, 0x0A))        // %PDF-1.4
            out.bytes(byteArrayOf(0x25, 0xE2.toByte(), 0xE3.toByte(), 0xCF.toByte(), 0xD3.toByte(), 0x0A))
            offsets[1] = out.n
            out.str("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")
            val kids = StringBuilder()
            for (i in 0 until count) kids.append(3 + 3 * i).append(" 0 R ")
            offsets[2] = out.n
            out.str("2 0 obj\n<< /Type /Pages /Kids [ $kids] /Count $count >>\nendobj\n")
            for (i in 0 until count) {
                val f = pages[i]
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeFile(f.absolutePath, o)
                val iw = maxOf(1, o.outWidth)
                val ih = maxOf(1, o.outHeight)
                val pw = 595.28f
                val ph = pw * ih / iw
                val pageObj = 3 + 3 * i
                val contObj = pageObj + 1
                val imgObj = pageObj + 2
                val dims = String.format(Locale.US, "%.2f %.2f", pw, ph)
                offsets[pageObj] = out.n
                out.str(
                    "$pageObj 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 $dims] " +
                        "/Resources << /XObject << /Im0 $imgObj 0 R >> >> /Contents $contObj 0 R >>\nendobj\n"
                )
                val cm = String.format(Locale.US, "q %.2f 0 0 %.2f 0 0 cm /Im0 Do Q\n", pw, ph)
                val contBytes = cm.toByteArray(Charsets.ISO_8859_1)
                offsets[contObj] = out.n
                out.str("$contObj 0 obj\n<< /Length ${contBytes.size} >>\nstream\n")
                out.bytes(contBytes)
                out.str("endstream\nendobj\n")
                val data = f.readBytes()
                offsets[imgObj] = out.n
                out.str(
                    "$imgObj 0 obj\n<< /Type /XObject /Subtype /Image /Width $iw /Height $ih " +
                        "/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${data.size} >>\nstream\n"
                )
                out.bytes(data)
                out.str("\nendstream\nendobj\n")
            }
            val xref = out.n
            val sb = StringBuilder()
            sb.append("xref\n0 ").append(total + 1).append("\n")
            sb.append("0000000000 65535 f \n")
            for (k in 1..total) sb.append(String.format(Locale.US, "%010d 00000 n \n", offsets[k]))
            sb.append("trailer\n<< /Size ").append(total + 1).append(" /Root 1 0 R >>\nstartxref\n")
            sb.append(xref).append("\n%%EOF\n")
            out.str(sb.toString())
        } finally {
            out.os.close()
        }
    }
}

object PdfImport {
    /** Renders every page of a PDF to a bitmap (about 200 dpi A4). Returns the number of pages read. */
    fun render(ctx: Context, uri: Uri, onPage: (Bitmap) -> Unit): Int {
        var pfd: ParcelFileDescriptor? = null
        var n = 0
        try {
            pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return 0
            val r = PdfRenderer(pfd)
            try {
                for (i in 0 until r.pageCount) {
                    val page = r.openPage(i)
                    try {
                        val targetW = 1654
                        val scale = targetW.toFloat() / page.width
                        val bw = targetW
                        val bh = maxOf(1, Math.round(page.height * scale))
                        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
                        Canvas(bmp).drawColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        onPage(bmp)
                        n++
                    } finally {
                        page.close()
                    }
                }
            } finally {
                r.close()
            }
        } catch (e: Exception) {
            return n
        } finally {
            try { pfd?.close() } catch (e: Exception) { }
        }
        return n
    }
}

object DocxWriter {
    private fun clean(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            if (ch == '\t' || ch == '\n' || ch == '\r' || ch >= ' ') sb.append(ch)
        }
        return sb.toString()
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
    }

    fun write(target: File, text: String) {
        val body = StringBuilder()
        for (raw in text.replace("\r\n", "\n").split("\n")) {
            val rtl = Util.hasArabic(raw)
            body.append("<w:p>")
            if (rtl) body.append("<w:pPr><w:bidi/></w:pPr>")
            body.append("<w:r><w:rPr><w:rFonts w:ascii=\"Arial\" w:hAnsi=\"Arial\" w:cs=\"Arial\"/>")
            if (rtl) body.append("<w:rtl/>")
            body.append("<w:sz w:val=\"26\"/><w:szCs w:val=\"26\"/></w:rPr>")
            body.append("<w:t xml:space=\"preserve\">").append(clean(raw)).append("</w:t></w:r></w:p>")
        }
        val doc = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>" +
            body + "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
            "<w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/>" +
            "</w:sectPr></w:body></w:document>"
        val types = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            "</Types>"
        val rels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "</Relationships>"
        ZipOutputStream(BufferedOutputStream(FileOutputStream(target))).use { z ->
            z.putNextEntry(ZipEntry("[Content_Types].xml"))
            z.write(types.toByteArray(Charsets.UTF_8))
            z.closeEntry()
            z.putNextEntry(ZipEntry("_rels/.rels"))
            z.write(rels.toByteArray(Charsets.UTF_8))
            z.closeEntry()
            z.putNextEntry(ZipEntry("word/document.xml"))
            z.write(doc.toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
    }
}

object Exporter {
    fun pdf(ctx: Context, d: Doc): File {
        val f = File(Util.exportsDir(ctx), Util.safeName(d.title) + ".pdf")
        val pages = ArrayList<File>()
        for (n in d.pages) pages.add(DocStore.pageFile(ctx, d, n))
        PdfWriter.write(f, pages)
        return f
    }

    fun images(ctx: Context, d: Doc): List<File> {
        val out = ArrayList<File>()
        val base = Util.safeName(d.title)
        var i = 1
        for (n in d.pages) {
            val f = File(Util.exportsDir(ctx), String.format(Locale.US, "%s_%02d.jpg", base, i))
            DocStore.pageFile(ctx, d, n).copyTo(f, true)
            out.add(f)
            i++
        }
        return out
    }

    fun txt(ctx: Context, d: Doc): File {
        val f = File(Util.exportsDir(ctx), Util.safeName(d.title) + ".txt")
        f.writeText(d.text, Charsets.UTF_8)
        return f
    }

    fun docx(ctx: Context, d: Doc): File {
        val f = File(Util.exportsDir(ctx), Util.safeName(d.title) + ".docx")
        DocxWriter.write(f, d.text)
        return f
    }
}
