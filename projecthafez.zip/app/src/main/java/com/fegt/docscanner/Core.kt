package com.fegt.docscanner

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

object Lang {
    const val PREFS = "safha"
    const val KEY = "lang"

    fun current(base: Context): String {
        val saved = base.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        return saved ?: if (Locale.getDefault().language == "ar") "ar" else "fr"
    }
}

object Bg {
    val pool: ExecutorService = Executors.newFixedThreadPool(2)
    val thumbPool: ExecutorService = Executors.newSingleThreadExecutor()
}

open class BaseActivity : ComponentActivity() {

    override fun attachBaseContext(base: Context) {
        val lang = Lang.current(base)
        val locale = if (lang == "ar") Locale("ar", "MA") else Locale("fr", "FR")
        Locale.setDefault(locale)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(locale)
        cfg.setLayoutDirection(locale)
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    protected fun isArabic(): Boolean = resources.configuration.locales[0].language == "ar"

    protected fun alive(): Boolean = !isFinishing && !isDestroyed

    protected fun toast(res: Int) {
        Toast.makeText(this, res, Toast.LENGTH_LONG).show()
    }

    protected fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    protected fun inBg(work: () -> Unit) {
        Bg.pool.execute { work() }
    }

    protected fun onUi(block: () -> Unit) {
        runOnUiThread { if (alive()) block() }
    }

    /** Runs [work] off the UI thread behind a busy dialog; [done] runs on the UI thread on success. */
    protected fun <T : Any> runBusy(msg: Int, work: () -> T, done: (T) -> Unit) {
        val dlg = Ui.busy(this, msg)
        inBg {
            val r: T? = try { work() } catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }
            onUi {
                dlg.dismiss()
                if (r != null) done(r) else toast(R.string.error)
            }
        }
    }

    /** Personal documents (ID cards...) ask for confirmation before leaving the app. */
    protected fun withPersonalWarning(d: Doc, go: () -> Unit) {
        if (d.kind != "id") {
            go()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.id_warn_title)
            .setMessage(R.string.id_warn_msg)
            .setPositiveButton(R.string.continue_) { _, _ -> go() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    protected fun sharePdfOf(d: Doc) {
        if (d.pages.isEmpty()) return
        withPersonalWarning(d) {
            runBusy(R.string.exporting, { Exporter.pdf(this, d) }) { f ->
                Util.share(this, f, "application/pdf", getString(R.string.share))
            }
        }
    }

    protected fun bar(titleRes: Int, onBack: () -> Unit) {
        findViewById<TextView>(R.id.barTitle).setText(titleRes)
        findViewById<View>(R.id.barBack).setOnClickListener { onBack() }
    }

    protected fun barAction(id: Int, icon: Int, desc: Int, onClick: () -> Unit) {
        val v = findViewById<ImageView>(id)
        v.setImageResource(icon)
        v.contentDescription = getString(desc)
        v.visibility = View.VISIBLE
        v.setOnClickListener { onClick() }
    }
}

object Util {
    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun date(t: Long): String = SimpleDateFormat("dd/MM/yyyy  HH:mm", Locale.US).format(Date(t))

    fun today(): String = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date())

    fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    fun uriOf(ctx: Context, f: File): Uri =
        FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)

    fun exportsDir(ctx: Context): File = File(ctx.filesDir, "exports").apply { mkdirs() }

    fun clearExports(ctx: Context) {
        exportsDir(ctx).listFiles()?.forEach { it.delete() }
    }

    fun safeName(s: String): String {
        val t = s.replace(Regex("[\\\\/:*?\"<>|\\r\\n\\t]"), "_").trim()
        val cut = if (t.length > 60) t.substring(0, 60) else t
        return if (cut.isEmpty()) "SAFHA" else cut
    }

    /** Parses a decimal typed with Latin or Arabic-Indic digits and '.', ',' or '٫'. */
    fun num(s: String): Float {
        val sb = StringBuilder()
        for (ch in s.trim()) {
            when {
                ch in '٠'..'٩' -> sb.append(('0' + (ch - '٠')))
                ch == ',' || ch == '٫' -> sb.append('.')
                else -> sb.append(ch)
            }
        }
        return sb.toString().toFloatOrNull() ?: 0f
    }

    fun hasArabic(s: String): Boolean = s.any { it in '؀'..'ۿ' }

    fun copy(ctx: Context, text: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("SAFHA", text))
    }

    fun share(ctx: Context, f: File, mime: String, title: String) {
        val i = Intent(Intent.ACTION_SEND).setType(mime)
            .putExtra(Intent.EXTRA_STREAM, uriOf(ctx, f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, title))
    }

    fun shareMany(ctx: Context, files: List<File>, mime: String, title: String) {
        val uris = ArrayList<Uri>()
        for (f in files) uris.add(uriOf(ctx, f))
        val i = Intent(Intent.ACTION_SEND_MULTIPLE).setType(mime)
            .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, title))
    }

    fun shareText(ctx: Context, text: String, title: String) {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        ctx.startActivity(Intent.createChooser(i, title))
    }
}

object Ui {
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    /** Vertical icon + label tile. card=true gives the white rounded card look. */
    fun tile(
        ctx: Context, icon: Int, label: Int, tint: Int,
        card: Boolean, weighted: Boolean, onClick: () -> Unit
    ): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        val pad = Util.dp(ctx, 8)
        box.setPadding(pad, Util.dp(ctx, 12), pad, Util.dp(ctx, 10))
        if (card) box.setBackgroundResource(R.drawable.bg_card)
        val iv = ImageView(ctx)
        iv.setImageResource(icon)
        iv.setColorFilter(tint)
        box.addView(iv, LinearLayout.LayoutParams(Util.dp(ctx, 26), Util.dp(ctx, 26)))
        val tv = TextView(ctx)
        tv.setText(label)
        tv.textSize = 11f
        tv.setTextColor(tint)
        tv.gravity = Gravity.CENTER
        tv.maxLines = 2
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.topMargin = Util.dp(ctx, 5)
        box.addView(tv, lp)
        box.isClickable = true
        box.isFocusable = true
        box.setOnClickListener { onClick() }
        val outer = if (weighted) LinearLayout.LayoutParams(0, WRAP, 1f)
        else LinearLayout.LayoutParams(Util.dp(ctx, 78), WRAP)
        val m = Util.dp(ctx, 4)
        outer.setMargins(m, m, m, m)
        box.layoutParams = outer
        return box
    }

    fun chip(ctx: Context, text: String, on: Boolean): TextView {
        val tv = TextView(ctx)
        tv.text = text
        tv.textSize = 13f
        tv.gravity = Gravity.CENTER
        val h = Util.dp(ctx, 14)
        tv.setPadding(h, Util.dp(ctx, 7), h, Util.dp(ctx, 7))
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.marginEnd = Util.dp(ctx, 8)
        tv.layoutParams = lp
        setChip(ctx, tv, on)
        return tv
    }

    fun setChip(ctx: Context, tv: TextView, on: Boolean) {
        tv.setBackgroundResource(if (on) R.drawable.bg_chip_on else R.drawable.bg_chip)
        tv.setTextColor(if (on) Color.WHITE else ctx.getColor(R.color.navy))
    }

    fun busy(ctx: Context, msg: Int): AlertDialog {
        val ll = LinearLayout(ctx)
        ll.orientation = LinearLayout.HORIZONTAL
        ll.gravity = Gravity.CENTER_VERTICAL
        val p = Util.dp(ctx, 24)
        ll.setPadding(p, p, p, p)
        ll.addView(ProgressBar(ctx))
        val tv = TextView(ctx)
        tv.setText(msg)
        tv.textSize = 15f
        tv.setPadding(Util.dp(ctx, 16), 0, 0, 0)
        ll.addView(tv)
        val d = AlertDialog.Builder(ctx).setView(ll).setCancelable(false).create()
        d.show()
        return d
    }

    fun prompt(ctx: Context, title: Int, initial: String, hint: Int, onOk: (String) -> Unit) {
        val et = EditText(ctx)
        et.setText(initial)
        et.setHint(hint)
        et.setSingleLine(true)
        val box = LinearLayout(ctx)
        val p = Util.dp(ctx, 20)
        box.setPadding(p, Util.dp(ctx, 8), p, 0)
        box.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, WRAP))
        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setView(box)
            .setPositiveButton(R.string.ok) { _, _ -> onOk(et.text.toString().trim()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    fun choose(ctx: Context, title: String?, items: List<String>, onPick: (Int) -> Unit) {
        val b = AlertDialog.Builder(ctx)
        if (title != null) b.setTitle(title)
        b.setItems(items.toTypedArray()) { _, which -> onPick(which) }
        b.show()
    }

    fun confirm(ctx: Context, title: Int, msg: String, okLabel: Int, onOk: () -> Unit) {
        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setMessage(msg)
            .setPositiveButton(okLabel) { _, _ -> onOk() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
