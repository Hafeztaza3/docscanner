package com.fegt.docscanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import android.net.Uri
import android.util.LruCache
import android.widget.ImageView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class Doc(val id: String) {
    var title: String = ""
    var kind: String = "scan"
    var created: Long = 0L
    var updated: Long = 0L
    var text: String = ""
    val pages: ArrayList<String> = ArrayList()
}

object DocStore {
    const val MAX_SIDE = 2600

    private fun root(ctx: Context): File = File(ctx.filesDir, "docs").apply { mkdirs() }

    fun dir(ctx: Context, id: String): File = File(root(ctx), id)

    fun pageFile(ctx: Context, d: Doc, name: String): File = File(dir(ctx, d.id), name)

    fun origFile(ctx: Context, d: Doc, name: String): File = File(dir(ctx, d.id), "$name.orig")

    fun list(ctx: Context): List<Doc> {
        val out = ArrayList<Doc>()
        val dirs = root(ctx).listFiles() ?: return out
        for (f in dirs) {
            if (!f.isDirectory) continue
            val d = load(ctx, f.name)
            if (d != null) out.add(d)
        }
        out.sortByDescending { it.updated }
        return out
    }

    fun load(ctx: Context, id: String): Doc? {
        val f = File(dir(ctx, id), "doc.json")
        if (!f.exists()) return null
        return try {
            val o = JSONObject(f.readText(Charsets.UTF_8))
            val d = Doc(id)
            d.title = o.optString("title", "")
            d.kind = o.optString("kind", "scan")
            d.created = o.optLong("created", 0L)
            d.updated = o.optLong("updated", 0L)
            d.text = o.optString("text", "")
            val arr = o.optJSONArray("pages")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val n = arr.getString(i)
                    if (File(dir(ctx, id), n).exists()) d.pages.add(n)
                }
            }
            d
        } catch (e: Exception) {
            null
        }
    }

    fun save(ctx: Context, d: Doc) {
        d.updated = System.currentTimeMillis()
        val o = JSONObject()
        o.put("title", d.title)
        o.put("kind", d.kind)
        o.put("created", d.created)
        o.put("updated", d.updated)
        o.put("text", d.text)
        val arr = JSONArray()
        for (p in d.pages) arr.put(p)
        o.put("pages", arr)
        val dir = dir(ctx, d.id)
        dir.mkdirs()
        val tmp = File(dir, "doc.json.tmp")
        tmp.writeText(o.toString(), Charsets.UTF_8)
        val fin = File(dir, "doc.json")
        if (!tmp.renameTo(fin)) {
            fin.writeText(o.toString(), Charsets.UTF_8)
            tmp.delete()
        }
    }

    fun create(ctx: Context, title: String, kind: String): Doc {
        val d = Doc(System.currentTimeMillis().toString() + UUID.randomUUID().toString().substring(0, 4))
        d.title = title
        d.kind = kind
        d.created = System.currentTimeMillis()
        dir(ctx, d.id).mkdirs()
        save(ctx, d)
        return d
    }

    fun delete(ctx: Context, id: String) {
        dir(ctx, id).deleteRecursively()
    }

    private fun newName(): String = "p" + UUID.randomUUID().toString().substring(0, 8) + ".jpg"

    fun writeJpeg(f: File, bmp: Bitmap, quality: Int) {
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
    }

    /** Writes the bitmap as a new page file and inserts it at [index] (or appends when index < 0). */
    fun addPage(ctx: Context, d: Doc, bmp: Bitmap, index: Int): String {
        val n = newName()
        writeJpeg(pageFile(ctx, d, n), bmp, 90)
        if (index < 0 || index > d.pages.size) d.pages.add(n) else d.pages.add(index, n)
        return n
    }

    fun removePage(ctx: Context, d: Doc, name: String) {
        pageFile(ctx, d, name).delete()
        origFile(ctx, d, name).delete()
        d.pages.remove(name)
    }
}

object Img {
    private fun sampleFor(w: Int, h: Int, maxSide: Int): Int {
        var s = 1
        while (maxOf(w, h) / (s * 2) >= maxSide) s *= 2
        return s
    }

    fun decodeFile(f: File, maxSide: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(f.absolutePath, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sampleFor(o.outWidth, o.outHeight, maxSide)
        val b = BitmapFactory.decodeFile(f.absolutePath, o2) ?: return null
        return limit(b, maxSide)
    }

    fun decodeUri(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val cr = ctx.contentResolver
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            if (o.outWidth <= 0 || o.outHeight <= 0) return null
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = sampleFor(o.outWidth, o.outHeight, maxSide)
            var b = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
            var orient = ExifInterface.ORIENTATION_NORMAL
            try {
                cr.openInputStream(uri)?.use {
                    orient = ExifInterface(it).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )
                }
            } catch (e: Exception) {
                orient = ExifInterface.ORIENTATION_NORMAL
            }
            b = orient(b, orient)
            flatten(limit(b, maxSide))
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    private fun orient(b: Bitmap, o: Int): Bitmap {
        val m = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            else -> return b
        }
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    fun limit(b: Bitmap, maxSide: Int): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= maxSide) return b
        val k = maxSide.toFloat() / m
        val nw = maxOf(1, Math.round(b.width * k))
        val nh = maxOf(1, Math.round(b.height * k))
        return Bitmap.createScaledBitmap(b, nw, nh, true)
    }

    /** Composites on white so JPEG never turns transparency into black. */
    fun flatten(b: Bitmap): Bitmap {
        if (!b.hasAlpha()) return b
        val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.WHITE)
        c.drawBitmap(b, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }
}

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun load(iv: ImageView, f: File, size: Int) {
        val key = f.absolutePath + "#" + f.lastModified() + "#" + size
        iv.tag = key
        val c = cache.get(key)
        if (c != null) {
            iv.setImageBitmap(c)
            return
        }
        iv.setImageDrawable(null)
        Bg.thumbPool.execute {
            val b = try { Img.decodeFile(f, size) } catch (e: OutOfMemoryError) { null }
            if (b != null) {
                cache.put(key, b)
                iv.post { if (iv.tag == key) iv.setImageBitmap(b) }
            }
        }
    }
}
