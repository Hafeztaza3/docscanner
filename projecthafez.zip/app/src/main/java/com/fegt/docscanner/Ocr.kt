package com.fegt.docscanner

import android.content.Context
import android.graphics.Bitmap
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File

class OcrEngine(private val ctx: Context) {
    private var api: TessBaseAPI? = null
    private var lang: String = ""

    private fun dataRoot(): File {
        val root = File(ctx.filesDir, "ocr")
        val td = File(root, "tessdata")
        td.mkdirs()
        for (n in arrayOf("ara.traineddata", "fra.traineddata")) {
            val f = File(td, n)
            if (f.exists() && f.length() > 100000L) continue
            val tmp = File(td, "$n.tmp")
            ctx.assets.open("tessdata/$n").use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            if (!tmp.renameTo(f)) {
                tmp.copyTo(f, true)
                tmp.delete()
            }
        }
        return root
    }

    /** lang: "ara+fra", "ara" or "fra". Returns false when the engine cannot start. */
    fun open(langCodes: String): Boolean {
        if (api != null && lang == langCodes) return true
        close()
        return try {
            val a = TessBaseAPI()
            val ok = a.init(dataRoot().absolutePath, langCodes)
            if (!ok) {
                a.recycle()
                false
            } else {
                a.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
                api = a
                lang = langCodes
                true
            }
        } catch (e: Exception) {
            false
        } catch (e: UnsatisfiedLinkError) {
            false
        }
    }

    fun recognize(bmp: Bitmap): String {
        val a = api ?: return ""
        a.setImage(bmp)
        val t = a.getUTF8Text() ?: ""
        a.clear()
        return t.trim()
    }

    fun stop() {
        try { api?.stop() } catch (e: Exception) { }
    }

    fun close() {
        try { api?.recycle() } catch (e: Exception) { }
        api = null
        lang = ""
    }
}
