package com.fegt.docscanner

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File

class DocActivity : BaseActivity() {

    private lateinit var doc: Doc
    private lateinit var grid: GridView
    private lateinit var normalBar: LinearLayout
    private lateinit var selBar: LinearLayout
    private lateinit var titleView: TextView
    private val adapter = PageAdapter()
    private val selected = LinkedHashSet<Int>()
    private var selecting = false
    private var replaceIndex = -1
    private var pendingSave: File? = null

    private val scanLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { r ->
        if (r.resultCode == RESULT_OK) onScanned(ScanHelper.uris(r.data))
    }

    private val pickImages = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) importUris(uris, false)
    }

    private val pickPdfs = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) importUris(uris, true)
    }

    private val editLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) {
            DocStore.save(this, doc)
        }
    }

    private val saveLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uri = r.data?.data
        val f = pendingSave
        pendingSave = null
        if (r.resultCode == RESULT_OK && uri != null && f != null) copyTo(f, uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("doc")
        val d = if (id == null) null else DocStore.load(this, id)
        if (d == null) {
            finish()
            return
        }
        doc = d
        if (doc.kind == "id") window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_doc)
        titleView = findViewById(R.id.barTitle)
        findViewById<View>(R.id.barBack).setOnClickListener { finish() }
        titleView.setOnClickListener { renameDoc() }
        grid = findViewById(R.id.pageGrid)
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> onPageClick(pos) }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            if (!selecting) startSelecting(pos)
            true
        }
        normalBar = findViewById(R.id.docActions)
        selBar = findViewById(R.id.selActions)
        buildBars()
        titleView.text = doc.title
    }

    override fun onResume() {
        super.onResume()
        if (!::doc.isInitialized) return
        val d = DocStore.load(this, doc.id)
        if (d == null) {
            finish()
            return
        }
        doc = d
        titleView.text = doc.title
        refresh()
    }

    private fun buildBars() {
        val navy = getColor(R.color.navy)
        val danger = getColor(R.color.danger)
        normalBar.addView(Ui.tile(this, R.drawable.ic_add, R.string.doc_add, navy, false, true) { addPagesDialog() })
        normalBar.addView(Ui.tile(this, R.drawable.ic_text, R.string.doc_ocr, navy, false, true) {
            if (doc.pages.isNotEmpty()) startActivity(Intent(this, OcrActivity::class.java).putExtra("doc", doc.id))
        })
        normalBar.addView(Ui.tile(this, R.drawable.ic_pdf, R.string.doc_pdf, navy, false, true) { sharePdfOf(doc) })
        normalBar.addView(Ui.tile(this, R.drawable.ic_more, R.string.doc_more, navy, false, true) { moreDialog() })
        selBar.addView(Ui.tile(this, R.drawable.ic_extract, R.string.sel_extract, navy, false, true) { extractSelected() })
        selBar.addView(Ui.tile(this, R.drawable.ic_trash, R.string.sel_delete, danger, false, true) { deleteSelected() })
        selBar.addView(Ui.tile(this, R.drawable.ic_close, R.string.sel_cancel, navy, false, true) { stopSelecting() })
    }

    private fun persist() {
        DocStore.save(this, doc)
        refresh()
    }

    private fun refresh() {
        adapter.notifyDataSetChanged()
        if (selecting) updateSelTitle()
    }

    // ---------- selection ----------

    private fun startSelecting(pos: Int) {
        selecting = true
        selected.clear()
        selected.add(pos)
        normalBar.visibility = View.GONE
        selBar.visibility = View.VISIBLE
        updateSelTitle()
        refresh()
    }

    private fun stopSelecting() {
        selecting = false
        selected.clear()
        normalBar.visibility = View.VISIBLE
        selBar.visibility = View.GONE
        titleView.text = doc.title
        refresh()
    }

    private fun updateSelTitle() {
        titleView.text = getString(R.string.sel_count, selected.size)
    }

    override fun onBackPressed() {
        if (selecting) stopSelecting() else super.onBackPressed()
    }

    private fun extractSelected() {
        if (selected.isEmpty()) return
        val idx = ArrayList(selected)
        idx.sort()
        runBusy(R.string.busy, {
            val nd = DocStore.create(this, doc.title + " – " + getString(R.string.extract_suffix), doc.kind)
            for (i in idx) {
                if (i < 0 || i >= doc.pages.size) continue
                val src = DocStore.pageFile(this, doc, doc.pages[i])
                val name = "p" + System.nanoTime() + ".jpg"
                src.copyTo(DocStore.pageFile(this, nd, name), true)
                nd.pages.add(name)
            }
            DocStore.save(this, nd)
            nd.id
        }) { newId ->
            stopSelecting()
            startActivity(Intent(this, DocActivity::class.java).putExtra("doc", newId))
        }
    }

    private fun deleteSelected() {
        if (selected.isEmpty()) return
        Ui.confirm(this, R.string.delete_title, getString(R.string.sel_delete_msg), R.string.delete) {
            val names = ArrayList<String>()
            for (i in selected) if (i >= 0 && i < doc.pages.size) names.add(doc.pages[i])
            for (n in names) DocStore.removePage(this, doc, n)
            stopSelecting()
            persist()
        }
    }

    // ---------- pages ----------

    private fun onPageClick(pos: Int) {
        if (selecting) {
            if (selected.contains(pos)) selected.remove(pos) else selected.add(pos)
            if (selected.isEmpty()) stopSelecting() else refresh()
            return
        }
        pageMenu(pos)
    }

    private fun pageMenu(pos: Int) {
        val labels = ArrayList<String>()
        val codes = ArrayList<Int>()
        labels.add(getString(R.string.page_edit)); codes.add(0)
        if (pos > 0) { labels.add(getString(R.string.page_left)); codes.add(1) }
        if (pos < doc.pages.size - 1) { labels.add(getString(R.string.page_right)); codes.add(2) }
        labels.add(getString(R.string.page_replace)); codes.add(3)
        labels.add(getString(R.string.page_split)); codes.add(4)
        labels.add(getString(R.string.page_select)); codes.add(5)
        labels.add(getString(R.string.page_delete)); codes.add(6)
        Ui.choose(this, getString(R.string.page_n, pos + 1), labels) { which ->
            when (codes[which]) {
                0 -> startActivity2Edit(pos)
                1 -> movePage(pos, -1)
                2 -> movePage(pos, 1)
                3 -> { replaceIndex = pos; startScan(1) }
                4 -> askSplit(pos)
                5 -> startSelecting(pos)
                6 -> Ui.confirm(this, R.string.delete_title, getString(R.string.page_n, pos + 1), R.string.delete) {
                    DocStore.removePage(this, doc, doc.pages[pos])
                    persist()
                }
            }
        }
    }

    private fun startActivity2Edit(pos: Int) {
        editLauncher.launch(
            Intent(this, EditorActivity::class.java)
                .putExtra("doc", doc.id)
                .putExtra("page", doc.pages[pos])
        )
    }

    private fun movePage(pos: Int, delta: Int) {
        val to = pos + delta
        if (to < 0 || to >= doc.pages.size) return
        val n = doc.pages.removeAt(pos)
        doc.pages.add(to, n)
        persist()
    }

    private fun askSplit(pos: Int) {
        Ui.choose(
            this, getString(R.string.book_order_title),
            listOf(getString(R.string.book_ltr), getString(R.string.book_rtl))
        ) { which ->
            val rtl = which == 1
            runBusy(R.string.busy, {
                val name = doc.pages[pos]
                val b = Img.decodeFile(DocStore.pageFile(this, doc, name), DocStore.MAX_SIDE)
                if (b == null) {
                    false
                } else {
                    val h = ImageOps.splitHalves(b)
                    val first = if (rtl) h.second else h.first
                    val second = if (rtl) h.first else h.second
                    DocStore.addPage(this, doc, first, pos)
                    DocStore.addPage(this, doc, second, pos + 1)
                    DocStore.removePage(this, doc, name)
                    true
                }
            }) { ok ->
                if (ok) persist() else toast(R.string.error)
            }
        }
    }

    // ---------- adding pages ----------

    private fun addPagesDialog() {
        Ui.choose(
            this, getString(R.string.doc_add),
            listOf(getString(R.string.add_scan), getString(R.string.add_images), getString(R.string.add_pdf))
        ) { which ->
            when (which) {
                0 -> { replaceIndex = -1; startScan(100) }
                1 -> pickImages.launch("image/*")
                2 -> pickPdfs.launch("application/pdf")
            }
        }
    }

    private fun startScan(limit: Int) {
        ScanHelper.start(this, limit, scanLauncher) { toast(R.string.error_scanner) }
    }

    private fun onScanned(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val rep = replaceIndex
        replaceIndex = -1
        runBusy(R.string.busy, {
            if (rep >= 0 && rep < doc.pages.size) {
                val old = doc.pages[rep]
                val n = Ingest.addUris(this, doc, uris.subList(0, 1), Ingest.DOC, false, rep)
                if (n > 0) DocStore.removePage(this, doc, old)
                n
            } else {
                Ingest.addUris(this, doc, uris, Ingest.DOC, false, -1)
            }
        }) { n ->
            if (n == 0) toast(R.string.import_none)
            persist()
        }
    }

    private fun importUris(uris: List<Uri>, pdf: Boolean) {
        runBusy(R.string.busy, {
            var n = 0
            if (pdf) {
                for (u in uris) n += Ingest.addPdf(this, doc, u, -1)
            } else {
                n = Ingest.addUris(this, doc, uris, Ingest.DOC, false, -1)
            }
            n
        }) { n ->
            if (n == 0) toast(if (pdf) R.string.import_pdf_fail else R.string.import_none)
            persist()
        }
    }

    // ---------- more menu ----------

    private fun moreDialog() {
        val labels = listOf(
            getString(R.string.more_save_pdf),
            getString(R.string.more_share_images),
            getString(R.string.more_txt),
            getString(R.string.more_docx),
            getString(R.string.more_watermark),
            getString(R.string.more_rename),
            getString(R.string.more_delete)
        )
        Ui.choose(this, getString(R.string.doc_more), labels) { which ->
            when (which) {
                0 -> savePdf()
                1 -> shareImages()
                2 -> shareText(false)
                3 -> shareText(true)
                4 -> watermarkAll()
                5 -> renameDoc()
                6 -> Ui.confirm(this, R.string.delete_title, getString(R.string.delete_msg), R.string.delete) {
                    DocStore.delete(this, doc.id)
                    finish()
                }
            }
        }
    }

    private fun renameDoc() {
        Ui.prompt(this, R.string.rename_title, doc.title, R.string.rename_title) { t ->
            if (t.isNotEmpty()) {
                doc.title = t
                DocStore.save(this, doc)
                titleView.text = doc.title
            }
        }
    }

    private fun savePdf() {
        if (doc.pages.isEmpty()) return
        withPersonalWarning(doc) {
            runBusy(R.string.exporting, { Exporter.pdf(this, doc) }) { f ->
                pendingSave = f
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/pdf")
                    .putExtra(Intent.EXTRA_TITLE, f.name)
                try {
                    saveLauncher.launch(i)
                } catch (e: Exception) {
                    pendingSave = null
                    toast(R.string.error)
                }
            }
        }
    }

    private fun copyTo(f: File, uri: Uri) {
        inBg {
            val ok = try {
                contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                true
            } catch (e: Exception) {
                false
            }
            onUi { toast(if (ok) R.string.saved_ok else R.string.error) }
        }
    }

    private fun shareImages() {
        if (doc.pages.isEmpty()) return
        withPersonalWarning(doc) {
            runBusy(R.string.exporting, { Exporter.images(this, doc) }) { files ->
                Util.shareMany(this, files, "image/jpeg", getString(R.string.share))
            }
        }
    }

    private fun shareText(word: Boolean) {
        if (doc.text.isBlank()) {
            toast(R.string.need_ocr)
            return
        }
        withPersonalWarning(doc) {
            runBusy(R.string.exporting, { if (word) Exporter.docx(this, doc) else Exporter.txt(this, doc) }) { f ->
                val mime = if (word) "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                else "text/plain"
                Util.share(this, f, mime, getString(R.string.share))
            }
        }
    }

    private fun watermarkAll() {
        if (doc.pages.isEmpty()) return
        Ui.prompt(this, R.string.wm_title, "", R.string.wm_hint) { text ->
            if (text.isNotEmpty()) {
                runBusy(R.string.busy, {
                    for (n in ArrayList(doc.pages)) {
                        val pf = DocStore.pageFile(this, doc, n)
                        val of = DocStore.origFile(this, doc, n)
                        if (!of.exists()) pf.copyTo(of, true)
                        val b = Img.decodeFile(pf, DocStore.MAX_SIDE)
                        if (b != null) DocStore.writeJpeg(pf, ImageOps.watermark(b, text, 25), 90)
                    }
                    true
                }) { _ ->
                    toast(R.string.wm_done)
                    persist()
                }
            }
        }
    }

    // ---------- adapter ----------

    private inner class PageAdapter : BaseAdapter() {
        override fun getCount(): Int = if (::doc.isInitialized) doc.pages.size else 0
        override fun getItem(position: Int): Any = doc.pages[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: LayoutInflater.from(this@DocActivity).inflate(R.layout.item_page, parent, false)
            val img = v.findViewById<ImageView>(R.id.pageImg)
            Thumbs.load(img, DocStore.pageFile(this@DocActivity, doc, doc.pages[position]), 420)
            v.findViewById<TextView>(R.id.pageNum).text = (position + 1).toString()
            v.findViewById<View>(R.id.pageSel).visibility =
                if (selecting && selected.contains(position)) View.VISIBLE else View.GONE
            return v
        }
    }
}
