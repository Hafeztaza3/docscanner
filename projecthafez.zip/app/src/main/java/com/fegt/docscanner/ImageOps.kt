package com.fegt.docscanner

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.max
import kotlin.math.min

/** Non-destructive adjustment parameters used by the editor. */
class Adjust {
    var filter: Int = 0          // 0 original, 1 auto, 2 gray, 3 b&w, 4 restore
    var brightness: Int = 0      // -100..100
    var contrast: Int = 0        // -100..100
    var sharpen: Int = 0         // 0..100
    var denoise: Boolean = false

    fun copyOf(): Adjust {
        val a = Adjust()
        a.filter = filter
        a.brightness = brightness
        a.contrast = contrast
        a.sharpen = sharpen
        a.denoise = denoise
        return a
    }

    fun isIdentity(): Boolean =
        filter == 0 && brightness == 0 && contrast == 0 && sharpen == 0 && !denoise
}

object ImageOps {

    fun apply(src: Bitmap, a: Adjust): Bitmap {
        var b = src
        b = when (a.filter) {
            1 -> magic(b)
            2 -> gray(magic(b))
            3 -> blackWhite(b, a.brightness)
            4 -> restore(b)
            else -> b
        }
        if (a.filter != 3) b = brightnessContrast(b, a.brightness, a.contrast)
        if (a.denoise) b = denoise(b)
        if (a.sharpen > 0) b = sharpen(b, a.sharpen)
        return b
    }

    fun rotate(src: Bitmap, deg: Int): Bitmap {
        val m = Matrix()
        m.postRotate(deg.toFloat())
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun colorMatrix(src: Bitmap, cm: ColorMatrix): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.colorFilter = ColorMatrixColorFilter(cm)
        c.drawBitmap(src, 0f, 0f, p)
        return out
    }

    fun gray(src: Bitmap): Bitmap {
        val cm = ColorMatrix()
        cm.setSaturation(0f)
        return colorMatrix(src, cm)
    }

    fun brightnessContrast(src: Bitmap, brightness: Int, contrast: Int): Bitmap {
        if (brightness == 0 && contrast == 0) return src
        val scale = if (contrast >= 0) 1f + contrast / 100f else 1f + contrast / 200f
        val offset = brightness * 1.6f + 128f * (1f - scale)
        val cm = ColorMatrix(
            floatArrayOf(
                scale, 0f, 0f, 0f, offset,
                0f, scale, 0f, 0f, offset,
                0f, 0f, scale, 0f, offset,
                0f, 0f, 0f, 1f, 0f
            )
        )
        return colorMatrix(src, cm)
    }

    // ---------- helpers on packed pixels ----------

    private fun lumOf(p: Int): Int =
        (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 151 + (p and 255) * 28) shr 8

    private fun clamp8(v: Int): Int = if (v < 0) 0 else if (v > 255) 255 else v

    private fun integral(lum: IntArray, w: Int, h: Int): IntArray {
        val iw = w + 1
        val ii = IntArray(iw * (h + 1))
        for (y in 0 until h) {
            var row = 0
            for (x in 0 until w) {
                row += lum[y * w + x]
                ii[(y + 1) * iw + (x + 1)] = ii[y * iw + (x + 1)] + row
            }
        }
        return ii
    }

    private fun boxMean(ii: IntArray, w: Int, h: Int, x: Int, y: Int, r: Int): Int {
        val x0 = max(0, x - r)
        val x1 = min(w, x + r + 1)
        val y0 = max(0, y - r)
        val y1 = min(h, y + r + 1)
        val iw = w + 1
        val sum = ii[y1 * iw + x1] - ii[y0 * iw + x1] - ii[y1 * iw + x0] + ii[y0 * iw + x0]
        return sum / ((x1 - x0) * (y1 - y0))
    }

    private fun pixels(src: Bitmap): IntArray {
        val px = IntArray(src.width * src.height)
        src.getPixels(px, 0, src.width, 0, 0, src.width, src.height)
        return px
    }

    private fun toBitmap(px: IntArray, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** Shadow removal + paper whitening, colours are preserved. */
    fun magic(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = pixels(src)
        val lum = IntArray(w * h)
        for (i in px.indices) lum[i] = lumOf(px[i])
        val ii = integral(lum, w, h)
        val r = max(16, max(w, h) / 12)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                val bg = max(40, boxMean(ii, w, h, x, y, r))
                var g = 255f / (bg * 1.1f)
                if (g < 0.9f) g = 0.9f
                if (g > 3.5f) g = 3.5f
                val p = px[i]
                val rr = clamp8((((p shr 16) and 255) * g - 20f).times(1.25f).toInt())
                val gg = clamp8((((p shr 8) and 255) * g - 20f).times(1.25f).toInt())
                val bb = clamp8(((p and 255) * g - 20f).times(1.25f).toInt())
                px[i] = (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
            }
        }
        return toBitmap(px, w, h)
    }

    /** Adaptive threshold for clean text. bias: -100..100, positive = lighter. */
    fun blackWhite(src: Bitmap, bias: Int): Bitmap {
        val w = src.width
        val h = src.height
        val px = pixels(src)
        val lum = IntArray(w * h)
        for (i in px.indices) lum[i] = lumOf(px[i])
        val ii = integral(lum, w, h)
        val r = max(8, max(w, h) / 40)
        val t = 15 + (bias.coerceIn(-100, 100) * 12) / 100
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                val m = boxMean(ii, w, h, x, y, r)
                val l = lum[i]
                val black = l < 60 || (l < 215 && l * 100 < m * (100 - t))
                px[i] = if (black) Color.BLACK else Color.WHITE
            }
        }
        return toBitmap(px, w, h)
    }

    private fun blur3(px: IntArray, w: Int, h: Int): IntArray {
        val out = px.copyOf()
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                var rs = 0
                var gs = 0
                var bs = 0
                for (dy in -1..1) {
                    val row = (y + dy) * w + x
                    for (dx in -1..1) {
                        val p = px[row + dx]
                        rs += (p shr 16) and 255
                        gs += (p shr 8) and 255
                        bs += p and 255
                    }
                }
                out[y * w + x] = (0xFF shl 24) or ((rs / 9) shl 16) or ((gs / 9) shl 8) or (bs / 9)
            }
        }
        return out
    }

    fun denoise(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = pixels(src)
        val bl = blur3(px, w, h)
        for (i in px.indices) {
            val a = px[i]
            val b = bl[i]
            val r = (((a shr 16) and 255) * 4 + ((b shr 16) and 255) * 6) / 10
            val g = (((a shr 8) and 255) * 4 + ((b shr 8) and 255) * 6) / 10
            val bb = ((a and 255) * 4 + (b and 255) * 6) / 10
            px[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bb
        }
        return toBitmap(px, w, h)
    }

    fun sharpen(src: Bitmap, amount: Int): Bitmap {
        if (amount <= 0) return src
        val w = src.width
        val h = src.height
        val px = pixels(src)
        val bl = blur3(px, w, h)
        val k = amount / 100f * 1.6f
        for (i in px.indices) {
            val a = px[i]
            val b = bl[i]
            val ar = (a shr 16) and 255
            val ag = (a shr 8) and 255
            val ab = a and 255
            val r = clamp8((ar + k * (ar - ((b shr 16) and 255))).toInt())
            val g = clamp8((ag + k * (ag - ((b shr 8) and 255))).toInt())
            val bb = clamp8((ab + k * (ab - (b and 255))).toInt())
            px[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bb
        }
        return toBitmap(px, w, h)
    }

    /** Simplified offline restoration: auto-levels, light saturation boost, mild denoise and sharpen. */
    fun restore(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = pixels(src)
        val hist = Array(3) { IntArray(256) }
        for (p in px) {
            hist[0][(p shr 16) and 255]++
            hist[1][(p shr 8) and 255]++
            hist[2][p and 255]++
        }
        val total = px.size
        val lut = Array(3) { IntArray(256) }
        for (c in 0..2) {
            var acc = 0
            var lo = 0
            var hi = 255
            var found = false
            for (v in 0..255) {
                acc += hist[c][v]
                if (!found && acc >= total * 0.005) { lo = v; found = true }
                if (acc >= total * 0.995) { hi = v; break }
            }
            val span = max(1, hi - lo)
            for (v in 0..255) {
                lut[c][v] = if (span < 40) v else clamp8(((v - lo) * 255) / span)
            }
        }
        for (i in px.indices) {
            val p = px[i]
            val r = lut[0][(p shr 16) and 255]
            val g = lut[1][(p shr 8) and 255]
            val b = lut[2][p and 255]
            px[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        val leveled = toBitmap(px, w, h)
        val cm = ColorMatrix()
        cm.setSaturation(1.15f)
        return sharpen(denoise(colorMatrix(leveled, cm)), 40)
    }

    // ---------- eraser ----------

    /**
     * Erases the painted strokes (normalised 0..1 coordinates, brush width as a fraction of
     * image width) by interpolating the surrounding background. Works on the stroke bounds only.
     */
    fun eraseStrokes(src: Bitmap, strokes: List<Path>, widthFrac: Float): Bitmap {
        val w = src.width
        val h = src.height
        val sc = Matrix()
        sc.setScale(w.toFloat(), h.toFloat())
        val bw = max(2f, widthFrac * w)
        val scaled = ArrayList<Path>()
        val bounds = RectF()
        var first = true
        for (s in strokes) {
            val p = Path()
            s.transform(sc, p)
            val rf = RectF()
            p.computeBounds(rf, true)
            if (first) { bounds.set(rf); first = false } else bounds.union(rf)
            scaled.add(p)
        }
        if (first) return src
        bounds.inset(-bw, -bw)
        val x0 = max(0, Math.floor(bounds.left.toDouble()).toInt())
        val y0 = max(0, Math.floor(bounds.top.toDouble()).toInt())
        val x1 = min(w, Math.ceil(bounds.right.toDouble()).toInt())
        val y1 = min(h, Math.ceil(bounds.bottom.toDouble()).toInt())
        val rw = x1 - x0
        val rh = y1 - y0
        if (rw <= 2 || rh <= 2) return src

        val maskBmp = Bitmap.createBitmap(rw, rh, Bitmap.Config.ALPHA_8)
        val mc = Canvas(maskBmp)
        mc.translate(-x0.toFloat(), -y0.toFloat())
        val paint = Paint()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = bw
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.isAntiAlias = false
        paint.color = Color.BLACK
        for (p in scaled) mc.drawPath(p, paint)
        val mpx = IntArray(rw * rh)
        maskBmp.getPixels(mpx, 0, rw, 0, 0, rw, rh)
        val mask = BooleanArray(rw * rh)
        var any = false
        for (i in mpx.indices) {
            if ((mpx[i] ushr 24) > 0) { mask[i] = true; any = true }
        }
        if (!any) return src

        val px = IntArray(rw * rh)
        src.getPixels(px, 0, rw, x0, y0, rw, rh)
        inpaint(px, mask, rw, rh)
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        out.setPixels(px, 0, rw, x0, y0, rw, rh)
        return out
    }

    private fun lerpColor(a: Int, b: Int, t: Float): Int {
        val r = (((a shr 16) and 255) * (1f - t) + ((b shr 16) and 255) * t).toInt()
        val g = (((a shr 8) and 255) * (1f - t) + ((b shr 8) and 255) * t).toInt()
        val bl = ((a and 255) * (1f - t) + (b and 255) * t).toInt()
        return (0xFF shl 24) or (clamp8(r) shl 16) or (clamp8(g) shl 8) or clamp8(bl)
    }

    private fun inpaint(px: IntArray, mask: BooleanArray, w: Int, h: Int) {
        val hp = IntArray(w * h)
        val hw = FloatArray(w * h)
        val vp = IntArray(w * h)
        val vw = FloatArray(w * h)
        // horizontal runs
        for (y in 0 until h) {
            var x = 0
            while (x < w) {
                if (!mask[y * w + x]) { x++; continue }
                var e = x
                while (e < w && mask[y * w + e]) e++
                val hasL = x > 0
                val hasR = e < w
                val len = (e - x).toFloat()
                for (k in x until e) {
                    val c = if (hasL && hasR) lerpColor(px[y * w + x - 1], px[y * w + e], (k - x + 1).toFloat() / (len + 1f))
                    else if (hasL) px[y * w + x - 1]
                    else if (hasR) px[y * w + e]
                    else 0
                    hp[y * w + k] = c
                    hw[y * w + k] = 1f / len
                }
                x = e
            }
        }
        // vertical runs
        for (x in 0 until w) {
            var y = 0
            while (y < h) {
                if (!mask[y * w + x]) { y++; continue }
                var e = y
                while (e < h && mask[e * w + x]) e++
                val hasT = y > 0
                val hasB = e < h
                val len = (e - y).toFloat()
                for (k in y until e) {
                    val c = if (hasT && hasB) lerpColor(px[(y - 1) * w + x], px[e * w + x], (k - y + 1).toFloat() / (len + 1f))
                    else if (hasT) px[(y - 1) * w + x]
                    else if (hasB) px[e * w + x]
                    else 0
                    vp[k * w + x] = c
                    vw[k * w + x] = 1f / len
                }
                y = e
            }
        }
        val res = px.copyOf()
        for (i in px.indices) {
            if (!mask[i]) continue
            val a = hp[i]
            val b = vp[i]
            res[i] = if (a != 0 && b != 0) {
                val t = vw[i] / (hw[i] + vw[i])
                lerpColor(a, b, t)
            } else if (a != 0) a else if (b != 0) b else Color.WHITE
        }
        for (i in px.indices) {
            if (mask[i]) px[i] = res[i]
        }
        // light smoothing of the filled area only
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                if (!mask[i]) continue
                var rs = 0
                var gs = 0
                var bs = 0
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val p = res[(y + dy) * w + x + dx]
                        rs += (p shr 16) and 255
                        gs += (p shr 8) and 255
                        bs += p and 255
                    }
                }
                px[i] = (0xFF shl 24) or ((rs / 9) shl 16) or ((gs / 9) shl 8) or (bs / 9)
            }
        }
    }

    // ---------- stamps ----------

    fun stamp(src: Bitmap, overlay: Bitmap, cx: Float, cy: Float, wFrac: Float): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        val dw = max(8f, wFrac * out.width)
        val dh = dw * overlay.height / overlay.width
        val l = cx * out.width - dw / 2f
        val t = cy * out.height - dh / 2f
        c.drawBitmap(overlay, null, RectF(l, t, l + dw, t + dh), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    /** Diagonal repeated text watermark. alphaPct 5..80. */
    fun watermark(src: Bitmap, text: String, alphaPct: Int): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        if (text.isBlank()) return out
        val c = Canvas(out)
        val w = out.width.toFloat()
        val h = out.height.toFloat()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.rgb(0, 25, 79)
        p.alpha = (alphaPct.coerceIn(5, 80) * 255) / 100
        p.textSize = max(18f, w / 22f)
        p.textAlign = Paint.Align.CENTER
        val stepY = p.textSize * 4.2f
        val stepX = max(p.measureText(text) + p.textSize * 2f, w / 2f)
        c.save()
        c.rotate(-30f, w / 2f, h / 2f)
        var row = 0
        var y = -h
        while (y < h * 2f) {
            val shift = if (row % 2 == 0) 0f else stepX / 2f
            var x = -w + shift
            while (x < w * 2f) {
                c.drawText(text, x, y, p)
                x += stepX
            }
            y += stepY
            row++
        }
        c.restore()
        return out
    }

    fun splitHalves(src: Bitmap): Pair<Bitmap, Bitmap> {
        val half = src.width / 2
        val left = Bitmap.createBitmap(src, 0, 0, half, src.height)
        val right = Bitmap.createBitmap(src, half, 0, src.width - half, src.height)
        return Pair(left, right)
    }
}
